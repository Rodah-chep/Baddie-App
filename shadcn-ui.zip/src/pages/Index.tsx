import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import CheckIn from '@/components/CheckIn';
import MoodDashboard from '@/components/MoodDashboard';
import ResourceLibrary from '@/components/ResourceLibrary';
import SupportAlert from '@/components/SupportAlert';
import { MoodEntry } from '@/lib/moodCalculations';
import { initializeUser, getTodaysMoodEntry, getLatestMoodEntry, hasLowMoodTrend } from '@/lib/localStorage';
import { Heart, BarChart3, BookOpen, Calendar } from 'lucide-react';

export default function Index() {
  const [user, setUser] = useState(initializeUser());
  const [todaysEntry, setTodaysEntry] = useState<MoodEntry | null>(null);
  const [latestEntry, setLatestEntry] = useState<MoodEntry | null>(null);
  const [showCheckIn, setShowCheckIn] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    const todayEntry = getTodaysMoodEntry();
    const latest = getLatestMoodEntry();
    
    setTodaysEntry(todayEntry);
    setLatestEntry(latest);
    
    // Show check-in if no entry today
    if (!todayEntry) {
      setShowCheckIn(true);
      setActiveTab('checkin');
    }
  }, []);

  const handleCheckInComplete = (entry: MoodEntry) => {
    setTodaysEntry(entry);
    setLatestEntry(entry);
    setShowCheckIn(false);
    setActiveTab('dashboard');
  };

  const handleNewCheckIn = () => {
    setShowCheckIn(true);
    setActiveTab('checkin');
  };

  const lowMoodTrend = hasLowMoodTrend();
  const showSupportAlert = latestEntry && (latestEntry.percentage <= 50 || lowMoodTrend);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
            Baddie 💜
          </h1>
          <p className="text-lg text-gray-600">
            Your compassionate mental health companion
          </p>
          {user && (
            <p className="text-sm text-gray-500 mt-2">
              Taking care of yourself since {user.signupDate.toLocaleDateString()}
            </p>
          )}
        </div>

        {/* Support Alert */}
        {showSupportAlert && (
          <div className="mb-6">
            <SupportAlert 
              percentage={latestEntry!.percentage} 
              hasLowTrend={lowMoodTrend}
            />
          </div>
        )}

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="checkin" className="flex items-center gap-2">
              <Heart className="w-4 h-4" />
              Check-In
            </TabsTrigger>
            <TabsTrigger value="resources" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Resources
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <MoodDashboard latestEntry={latestEntry} />
            
            {todaysEntry ? (
              <Card className="border-2 border-blue-200">
                <CardHeader className="text-center">
                  <CardTitle className="text-blue-800">Today's Check-In Complete! ✅</CardTitle>
                  <CardDescription>
                    You've already checked in today. Come back tomorrow for your next check-in, 
                    or explore resources to support your well-being.
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button
                    onClick={handleNewCheckIn}
                    variant="outline"
                    className="border-blue-300 text-blue-700 hover:bg-blue-50"
                  >
                    Take Another Check-In
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-2 border-purple-200">
                <CardHeader className="text-center">
                  <CardTitle className="text-purple-800">Ready for Today's Check-In? 💜</CardTitle>
                  <CardDescription>
                    Take a moment to reflect on how you've been feeling. Your mental health matters, baddie!
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button
                    onClick={handleNewCheckIn}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    Start Check-In
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="checkin">
            {showCheckIn ? (
              <CheckIn onComplete={handleCheckInComplete} />
            ) : (
              <Card className="border-2 border-purple-200">
                <CardHeader className="text-center">
                  <CardTitle className="text-purple-800">Check-In Complete! ✨</CardTitle>
                  <CardDescription>
                    Thank you for taking time to check in with yourself today.
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button
                    onClick={() => setActiveTab('dashboard')}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    View Your Results
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="resources">
            <ResourceLibrary wellBeingLevel={latestEntry?.wellBeingLevel || null} />
          </TabsContent>

          <TabsContent value="history">
            <Card className="border-2 border-indigo-200">
              <CardHeader>
                <CardTitle className="text-indigo-800">Your Wellness Journey 📊</CardTitle>
                <CardDescription>
                  Track your progress over time and celebrate your growth.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-gray-500">
                  <Calendar className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <p className="text-lg mb-2">History Feature Coming Soon!</p>
                  <p className="text-sm">
                    We're working on detailed analytics and insights to help you 
                    understand your mental health patterns better.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="text-center mt-12 text-sm text-gray-500">
          <p>
            Remember: This app is for support and self-reflection. 
            If you're in crisis, please reach out to a mental health professional or emergency services.
          </p>
          <p className="mt-2">
            You're doing great by taking care of your mental health, baddie! 💜
          </p>
        </div>
      </div>
    </div>
  );
}