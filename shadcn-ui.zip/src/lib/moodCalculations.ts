export interface WHO5Scores {
  cheerful: number;
  calm: number;
  active: number;
  rested: number;
  interest: number;
}

export interface MoodEntry {
  id: string;
  timestamp: Date;
  scores: WHO5Scores;
  rawScore: number;
  percentage: number;
  wellBeingLevel: 'low' | 'moderate' | 'high';
}

export const WHO5_QUESTIONS = [
  {
    key: 'cheerful' as keyof WHO5Scores,
    question: 'Felt cheerful and in good spirits?',
    description: 'How often have you felt positive and upbeat?'
  },
  {
    key: 'calm' as keyof WHO5Scores,
    question: 'Felt calm and relaxed?',
    description: 'How often have you felt peaceful and at ease?'
  },
  {
    key: 'active' as keyof WHO5Scores,
    question: 'Felt active and vigorous?',
    description: 'How often have you felt energetic and motivated?'
  },
  {
    key: 'rested' as keyof WHO5Scores,
    question: 'Woke up feeling fresh and rested?',
    description: 'How often have you felt well-rested after sleep?'
  },
  {
    key: 'interest' as keyof WHO5Scores,
    question: 'Had a daily life filled with things that interest you?',
    description: 'How often have you felt engaged and interested in activities?'
  }
];

export const RATING_OPTIONS = [
  { value: 0, label: 'At no time', emoji: '😔' },
  { value: 1, label: 'Some of the time', emoji: '😕' },
  { value: 2, label: 'Less than half of the time', emoji: '😐' },
  { value: 3, label: 'More than half of the time', emoji: '🙂' },
  { value: 4, label: 'Most of the time', emoji: '😊' },
  { value: 5, label: 'All of the time', emoji: '😄' }
];

export function calculateMoodScore(scores: WHO5Scores): { rawScore: number; percentage: number; wellBeingLevel: 'low' | 'moderate' | 'high' } {
  const rawScore = scores.cheerful + scores.calm + scores.active + scores.rested + scores.interest;
  const percentage = Math.round((rawScore / 25) * 100);
  
  let wellBeingLevel: 'low' | 'moderate' | 'high';
  if (percentage <= 50) {
    wellBeingLevel = 'low';
  } else if (percentage <= 75) {
    wellBeingLevel = 'moderate';
  } else {
    wellBeingLevel = 'high';
  }
  
  return { rawScore, percentage, wellBeingLevel };
}

export function getMoodMessage(percentage: number): { message: string; emoji: string; color: string } {
  if (percentage <= 50) {
    return {
      message: "Hey baddie, I see you're going through it right now. That's totally okay - you're not alone in this. 💜",
      emoji: "🫂",
      color: "text-red-600"
    };
  } else if (percentage <= 75) {
    return {
      message: "You're doing okay, baddie! Some ups and downs are totally normal. Keep taking care of yourself! ✨",
      emoji: "🌟",
      color: "text-yellow-600"
    };
  } else {
    return {
      message: "Look at you thriving, baddie! Your energy is absolutely glowing today! Keep shining! ✨",
      emoji: "💖",
      color: "text-green-600"
    };
  }
}