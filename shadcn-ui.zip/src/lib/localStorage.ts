import { MoodEntry } from './moodCalculations';

const MOOD_ENTRIES_KEY = 'baddie_mood_entries';
const USER_PREFERENCES_KEY = 'baddie_user_preferences';

export interface UserPreferences {
  dailyReminderTime?: string;
  anonymousId: string;
  signupDate: Date;
  lastActive: Date;
}

export function saveMoodEntry(entry: MoodEntry): void {
  const existingEntries = getMoodEntries();
  const updatedEntries = [...existingEntries, entry];
  localStorage.setItem(MOOD_ENTRIES_KEY, JSON.stringify(updatedEntries));
}

export function getMoodEntries(): MoodEntry[] {
  const stored = localStorage.getItem(MOOD_ENTRIES_KEY);
  if (!stored) return [];
  
  try {
    const entries: MoodEntry[] = JSON.parse(stored);
    return entries.map((entry: MoodEntry) => ({
      ...entry,
      timestamp: new Date(entry.timestamp)
    }));
  } catch (error) {
    console.error('Error parsing mood entries:', error);
    return [];
  }
}

export function getLatestMoodEntry(): MoodEntry | null {
  const entries = getMoodEntries();
  if (entries.length === 0) return null;
  
  return entries.reduce((latest, current) => 
    current.timestamp > latest.timestamp ? current : latest
  );
}

export function getTodaysMoodEntry(): MoodEntry | null {
  const entries = getMoodEntries();
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  return entries.find(entry => {
    const entryDate = new Date(entry.timestamp);
    entryDate.setHours(0, 0, 0, 0);
    return entryDate.getTime() === today.getTime();
  }) || null;
}

export function getMoodTrend(days: number = 7): MoodEntry[] {
  const entries = getMoodEntries();
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);
  
  return entries
    .filter(entry => entry.timestamp >= cutoffDate)
    .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
}

export function saveUserPreferences(preferences: UserPreferences): void {
  localStorage.setItem(USER_PREFERENCES_KEY, JSON.stringify(preferences));
}

export function getUserPreferences(): UserPreferences | null {
  const stored = localStorage.getItem(USER_PREFERENCES_KEY);
  if (!stored) return null;
  
  try {
    const prefs: UserPreferences = JSON.parse(stored);
    return {
      ...prefs,
      signupDate: new Date(prefs.signupDate),
      lastActive: new Date(prefs.lastActive)
    };
  } catch (error) {
    console.error('Error parsing user preferences:', error);
    return null;
  }
}

export function initializeUser(): UserPreferences {
  const existing = getUserPreferences();
  if (existing) {
    const updated = { ...existing, lastActive: new Date() };
    saveUserPreferences(updated);
    return updated;
  }
  
  const newUser: UserPreferences = {
    anonymousId: `baddie_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    signupDate: new Date(),
    lastActive: new Date()
  };
  
  saveUserPreferences(newUser);
  return newUser;
}

export function hasLowMoodTrend(): boolean {
  const recentEntries = getMoodTrend(7);
  const lastThreeEntries = recentEntries.slice(-3);
  
  return lastThreeEntries.length >= 3 && 
         lastThreeEntries.every(entry => entry.percentage <= 50);
}