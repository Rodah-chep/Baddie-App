import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { Phone, Heart, MessageCircle, Sparkles, Video, BookOpen, Headphones, Zap } from 'lucide-react';

interface QuickActionsProps {
  wellBeingLevel: 'low' | 'moderate' | 'high' | null;
  onActionClick: (action: string) => void;
}

export default function QuickActions({ wellBeingLevel, onActionClick }: QuickActionsProps) {
  const getActions = () => {
    const baseActions = [
      {
        id: 'meditation',
        label: 'Guided Meditation',
        icon: <Heart className="w-5 h-5" />,
        color: 'bg-purple-500 hover:bg-purple-600',
        description: '5-min calm session'
      },
      {
        id: 'share',
        label: 'Share Feelings',
        icon: <MessageCircle className="w-5 h-5" />,
        color: 'bg-blue-500 hover:bg-blue-600',
        description: 'Express yourself'
      }
    ];

    if (wellBeingLevel === 'low') {
      return [
        {
          id: 'support',
          label: 'Talk to Support',
          icon: <Phone className="w-5 h-5" />,
          color: 'bg-red-500 hover:bg-red-600',
          description: 'Immediate help'
        },
        {
          id: 'breathing',
          label: 'Breathing Exercise',
          icon: <Zap className="w-5 h-5" />,
          color: 'bg-indigo-500 hover:bg-indigo-600',
          description: '4-7-8 technique'
        },
        ...baseActions
      ];
    }

    if (wellBeingLevel === 'moderate') {
      return [
        ...baseActions,
        {
          id: 'podcast',
          label: 'Wellness Podcast',
          icon: <Headphones className="w-5 h-5" />,
          color: 'bg-green-500 hover:bg-green-600',
          description: 'Inspiring stories'
        },
        {
          id: 'journal',
          label: 'Quick Journal',
          icon: <BookOpen className="w-5 h-5" />,
          color: 'bg-orange-500 hover:bg-orange-600',
          description: 'Reflect & write'
        }
      ];
    }

    // High well-being
    return [
      {
        id: 'boost',
        label: 'Mood Boost',
        icon: <Sparkles className="w-5 h-5" />,
        color: 'bg-yellow-500 hover:bg-yellow-600',
        description: 'Energize yourself'
      },
      {
        id: 'goals',
        label: 'Set Goals',
        icon: <BookOpen className="w-5 h-5" />,
        color: 'bg-green-500 hover:bg-green-600',
        description: 'Plan your growth'
      },
      ...baseActions,
      {
        id: 'video',
        label: 'Motivational Video',
        icon: <Video className="w-5 h-5" />,
        color: 'bg-pink-500 hover:bg-pink-600',
        description: 'Get inspired'
      }
    ];
  };

  const actions = getActions();

  const handleActionClick = (actionId: string) => {
    onActionClick(actionId);
    
    // Handle specific actions
    switch (actionId) {
      case 'support':
        window.open('tel:988', '_blank');
        break;
      case 'breathing':
        window.open('https://www.youtube.com/watch?v=YRPh_GaiL8s', '_blank');
        break;
      case 'meditation':
        window.open('https://www.youtube.com/watch?v=inpok4MKVLM', '_blank');
        break;
      case 'podcast':
        window.open('https://open.spotify.com/show/5CvLsMVFStaLDkqISBYkY2', '_blank');
        break;
      case 'video':
        window.open('https://www.youtube.com/watch?v=WPPPFqsECz0', '_blank');
        break;
      default:
        console.log(`Action clicked: ${actionId}`);
    }
  };

  return (
    <Card className="border-2 border-indigo-200 shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl text-indigo-800 flex items-center gap-2">
          ⚡ Quick Actions
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {actions.map((action, index) => (
            <motion.div
              key={action.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button
                onClick={() => handleActionClick(action.id)}
                className={`${action.color} text-white w-full h-auto p-4 flex flex-col items-center gap-2 shadow-lg hover:shadow-xl transition-all duration-200`}
              >
                <div className="text-white">
                  {action.icon}
                </div>
                <div className="text-center">
                  <div className="font-semibold text-sm">{action.label}</div>
                  <div className="text-xs opacity-90">{action.description}</div>
                </div>
              </Button>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}