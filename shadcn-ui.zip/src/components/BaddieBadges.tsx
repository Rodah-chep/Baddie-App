import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { motion } from 'framer-motion';
import { Trophy, Flame, Heart, Target, Star, Zap } from 'lucide-react';

interface BadgeData {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  earned: boolean;
  progress: number;
  maxProgress: number;
  category: 'streak' | 'consistency' | 'resilience' | 'engagement';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

interface BaddieBadgesProps {
  checkInStreak: number;
  totalCheckIns: number;
  resourcesViewed: number;
  moodImprovements: number;
}

export default function BaddieBadges({ 
  checkInStreak, 
  totalCheckIns, 
  resourcesViewed, 
  moodImprovements 
}: BaddieBadgesProps) {
  
  const badges: BadgeData[] = [
    {
      id: 'first-steps',
      name: 'First Steps',
      description: 'Complete your first check-in',
      icon: <Heart className="w-6 h-6" />,
      earned: totalCheckIns >= 1,
      progress: Math.min(totalCheckIns, 1),
      maxProgress: 1,
      category: 'engagement',
      rarity: 'common'
    },
    {
      id: 'streak-starter',
      name: 'Streak Starter',
      description: 'Check in for 3 days in a row',
      icon: <Flame className="w-6 h-6" />,
      earned: checkInStreak >= 3,
      progress: Math.min(checkInStreak, 3),
      maxProgress: 3,
      category: 'streak',
      rarity: 'common'
    },
    {
      id: 'week-warrior',
      name: 'Week Warrior',
      description: 'Maintain a 7-day check-in streak',
      icon: <Trophy className="w-6 h-6" />,
      earned: checkInStreak >= 7,
      progress: Math.min(checkInStreak, 7),
      maxProgress: 7,
      category: 'streak',
      rarity: 'rare'
    },
    {
      id: 'consistency-champion',
      name: 'Consistency Champion',
      description: 'Complete 30 total check-ins',
      icon: <Target className="w-6 h-6" />,
      earned: totalCheckIns >= 30,
      progress: Math.min(totalCheckIns, 30),
      maxProgress: 30,
      category: 'consistency',
      rarity: 'epic'
    },
    {
      id: 'resource-explorer',
      name: 'Resource Explorer',
      description: 'View 10 wellness resources',
      icon: <Star className="w-6 h-6" />,
      earned: resourcesViewed >= 10,
      progress: Math.min(resourcesViewed, 10),
      maxProgress: 10,
      category: 'engagement',
      rarity: 'rare'
    },
    {
      id: 'resilience-baddie',
      name: 'Resilience Baddie',
      description: 'Show mood improvement 5 times',
      icon: <Zap className="w-6 h-6" />,
      earned: moodImprovements >= 5,
      progress: Math.min(moodImprovements, 5),
      maxProgress: 5,
      category: 'resilience',
      rarity: 'legendary'
    }
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-gray-100 text-gray-800 border-gray-300';
      case 'rare': return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'epic': return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'legendary': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const earnedBadges = badges.filter(badge => badge.earned);
  const inProgressBadges = badges.filter(badge => !badge.earned && badge.progress > 0);
  const lockedBadges = badges.filter(badge => !badge.earned && badge.progress === 0);

  return (
    <Card className="border-2 border-yellow-200 shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl text-yellow-800 flex items-center gap-2">
          <Trophy className="w-6 h-6" />
          Baddie Badges
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Earned Badges */}
        {earnedBadges.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-green-800 mb-3">Earned Badges ✨</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {earnedBadges.map((badge, index) => (
                <motion.div
                  key={badge.id}
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ delay: index * 0.1, type: "spring", stiffness: 260, damping: 20 }}
                  whileHover={{ scale: 1.05 }}
                  className="relative"
                >
                  <Card className="border-2 border-green-300 bg-green-50 shadow-md">
                    <CardContent className="p-4 text-center">
                      <div className="text-green-600 mb-2 flex justify-center">
                        {badge.icon}
                      </div>
                      <h4 className="font-semibold text-green-800 text-sm mb-1">
                        {badge.name}
                      </h4>
                      <p className="text-xs text-green-600 mb-2">
                        {badge.description}
                      </p>
                      <Badge className={`text-xs ${getRarityColor(badge.rarity)}`}>
                        {badge.rarity}
                      </Badge>
                    </CardContent>
                  </Card>
                  
                  {/* Sparkle Animation */}
                  <motion.div
                    className="absolute -top-1 -right-1 text-yellow-400"
                    animate={{
                      rotate: [0, 360],
                      scale: [1, 1.2, 1]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  >
                    ✨
                  </motion.div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* In Progress Badges */}
        {inProgressBadges.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-blue-800 mb-3">Almost There! 🎯</h3>
            <div className="space-y-3">
              {inProgressBadges.map((badge) => (
                <motion.div
                  key={badge.id}
                  whileHover={{ scale: 1.02 }}
                  className="border-2 border-blue-200 bg-blue-50 rounded-lg p-4"
                >
                  <div className="flex items-center gap-3">
                    <div className="text-blue-600">
                      {badge.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-semibold text-blue-800">
                          {badge.name}
                        </h4>
                        <Badge className={`text-xs ${getRarityColor(badge.rarity)}`}>
                          {badge.rarity}
                        </Badge>
                      </div>
                      <p className="text-sm text-blue-600 mb-2">
                        {badge.description}
                      </p>
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs text-blue-700">
                          <span>{badge.progress} / {badge.maxProgress}</span>
                          <span>{Math.round((badge.progress / badge.maxProgress) * 100)}%</span>
                        </div>
                        <Progress 
                          value={(badge.progress / badge.maxProgress) * 100} 
                          className="h-2"
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Locked Badges Preview */}
        {lockedBadges.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-gray-600 mb-3">Coming Up Next 🔒</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {lockedBadges.slice(0, 3).map((badge) => (
                <Card key={badge.id} className="border-2 border-gray-200 bg-gray-50 opacity-60">
                  <CardContent className="p-4 text-center">
                    <div className="text-gray-400 mb-2 flex justify-center">
                      {badge.icon}
                    </div>
                    <h4 className="font-semibold text-gray-600 text-sm mb-1">
                      {badge.name}
                    </h4>
                    <p className="text-xs text-gray-500 mb-2">
                      {badge.description}
                    </p>
                    <Badge className="text-xs bg-gray-200 text-gray-600">
                      {badge.rarity}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Stats Summary */}
        <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4 border border-purple-200">
          <h3 className="text-lg font-semibold text-purple-800 mb-3">Your Progress 📊</h3>
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-purple-600">{earnedBadges.length}</div>
              <div className="text-sm text-purple-700">Badges Earned</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">{checkInStreak}</div>
              <div className="text-sm text-purple-700">Current Streak</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}