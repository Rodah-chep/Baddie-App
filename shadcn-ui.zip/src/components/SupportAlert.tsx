import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, Phone, MessageCircle, Heart } from 'lucide-react';

interface SupportAlertProps {
  percentage: number;
  hasLowTrend: boolean;
}

export default function SupportAlert({ percentage, hasLowTrend }: SupportAlertProps) {
  const isLowMood = percentage <= 50;
  const isCritical = percentage <= 20;

  if (!isLowMood && !hasLowTrend) {
    return null;
  }

  const emergencyContacts = [
    {
      name: 'National Suicide Prevention Lifeline',
      number: '988',
      description: 'Free, confidential 24/7 support'
    },
    {
      name: 'Crisis Text Line',
      number: 'Text HOME to 741741',
      description: 'Free crisis counseling via text'
    },
    {
      name: 'SAMHSA National Helpline',
      number: '1-800-662-4357',
      description: 'Treatment referral and information service'
    }
  ];

  return (
    <div className="space-y-4">
      {isCritical && (
        <Alert className="border-red-500 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertTitle className="text-red-800">Immediate Support Available</AlertTitle>
          <AlertDescription className="text-red-700">
            It looks like you're going through a really tough time right now. You don't have to face this alone - there are people who want to help.
          </AlertDescription>
        </Alert>
      )}

      <Card className="border-2 border-red-200 bg-red-50">
        <CardHeader>
          <CardTitle className="text-red-800 flex items-center gap-2">
            <Heart className="w-5 h-5" />
            {hasLowTrend ? 'We\'ve Noticed You\'re Struggling' : 'You Matter, Baddie 💜'}
          </CardTitle>
          <CardDescription className="text-red-700">
            {hasLowTrend 
              ? 'Your recent check-ins show you\'ve been having a hard time. That takes courage to acknowledge, and we\'re here to support you.'
              : 'Your well-being score suggests you might need some extra support right now. That\'s completely okay - reaching out is a sign of strength.'
            }
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="bg-white p-4 rounded-lg border border-red-200">
            <h4 className="font-semibold text-red-800 mb-3 flex items-center gap-2">
              <Phone className="w-4 h-4" />
              Immediate Support Resources
            </h4>
            <div className="space-y-3">
              {emergencyContacts.map((contact, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-red-50 rounded border">
                  <div>
                    <div className="font-medium text-red-800">{contact.name}</div>
                    <div className="text-sm text-red-600">{contact.description}</div>
                  </div>
                  <Button
                    size="sm"
                    className="bg-red-600 hover:bg-red-700 text-white"
                    onClick={() => {
                      if (contact.number.includes('Text')) {
                        window.open(`sms:741741?body=HOME`, '_blank');
                      } else {
                        window.open(`tel:${contact.number.replace(/[^\d]/g, '')}`, '_blank');
                      }
                    }}
                  >
                    {contact.number.includes('Text') ? (
                      <><MessageCircle className="w-4 h-4 mr-1" />Text</>
                    ) : (
                      <><Phone className="w-4 h-4 mr-1" />Call</>
                    )}
                  </Button>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg border border-red-200">
            <h4 className="font-semibold text-red-800 mb-2">Remember, Baddie:</h4>
            <ul className="text-sm text-red-700 space-y-1">
              <li>• This feeling is temporary, even though it doesn't feel that way right now</li>
              <li>• You've gotten through difficult times before, and you can get through this too</li>
              <li>• Asking for help is brave, not weak</li>
              <li>• You deserve support, care, and compassion</li>
              <li>• Small steps count - even checking in with yourself today was important</li>
            </ul>
          </div>

          {hasLowTrend && (
            <Alert className="border-orange-300 bg-orange-50">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
              <AlertTitle className="text-orange-800">Consider Professional Support</AlertTitle>
              <AlertDescription className="text-orange-700">
                Since you've been struggling for several days, it might be helpful to talk to a mental health professional. 
                They can provide personalized strategies and support tailored to your specific situation.
              </AlertDescription>
            </Alert>
          )}

          <div className="text-center pt-2">
            <Button
              variant="outline"
              className="border-red-300 text-red-700 hover:bg-red-50"
              onClick={() => window.open('https://www.psychologytoday.com/us/therapists', '_blank')}
            >
              Find a Therapist Near Me
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}