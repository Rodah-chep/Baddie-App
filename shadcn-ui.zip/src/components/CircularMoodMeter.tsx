import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';

interface CircularMoodMeterProps {
  percentage: number;
  wellBeingLevel: 'low' | 'moderate' | 'high';
  onExpand?: () => void;
}

export default function CircularMoodMeter({ percentage, wellBeingLevel, onExpand }: CircularMoodMeterProps) {
  const [isHovered, setIsHovered] = useState(false);

  const getMoodColor = (level: string, percentage: number) => {
    if (level === 'low') return `hsl(${220 + percentage * 0.5}, 70%, 60%)`; // Blue to purple
    if (level === 'moderate') return `hsl(${60 + percentage * 0.8}, 70%, 60%)`; // Yellow to green
    return `hsl(${45 + percentage * 0.3}, 80%, 65%)`; // Orange to yellow
  };

  const getMoodGradient = (level: string, percentage: number) => {
    const color1 = getMoodColor(level, percentage - 10);
    const color2 = getMoodColor(level, percentage + 10);
    return `linear-gradient(135deg, ${color1}, ${color2})`;
  };

  const circumference = 2 * Math.PI * 90;
  const strokeDasharray = circumference;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  const getMoodEmoji = () => {
    if (percentage <= 30) return '🫂';
    if (percentage <= 50) return '😔';
    if (percentage <= 70) return '😐';
    if (percentage <= 85) return '🙂';
    return '😄';
  };

  const getMoodMessage = () => {
    if (percentage <= 30) return 'Sending you love, baddie 💜';
    if (percentage <= 50) return 'You\'re stronger than you know ✨';
    if (percentage <= 70) return 'You\'re doing okay, keep going! 🌟';
    if (percentage <= 85) return 'Looking good, baddie! 💫';
    return 'Absolutely glowing! 🌈';
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={onExpand}
      className="cursor-pointer"
    >
      <Card className="border-2 border-purple-200 shadow-lg overflow-hidden">
        <CardContent className="p-8">
          <div className="relative flex flex-col items-center">
            {/* Circular Progress */}
            <div className="relative w-48 h-48 mb-6">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
                {/* Background Circle */}
                <circle
                  cx="100"
                  cy="100"
                  r="90"
                  fill="none"
                  stroke="rgb(229, 231, 235)"
                  strokeWidth="8"
                />
                
                {/* Progress Circle */}
                <motion.circle
                  cx="100"
                  cy="100"
                  r="90"
                  fill="none"
                  stroke={`url(#gradient-${wellBeingLevel})`}
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={strokeDasharray}
                  strokeDashoffset={strokeDashoffset}
                  initial={{ strokeDashoffset: circumference }}
                  animate={{ strokeDashoffset }}
                  transition={{ duration: 2, ease: "easeOut" }}
                  className={isHovered ? 'drop-shadow-lg' : ''}
                />
                
                {/* Gradient Definitions */}
                <defs>
                  <linearGradient id={`gradient-${wellBeingLevel}`} x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor={getMoodColor(wellBeingLevel, percentage - 15)} />
                    <stop offset="100%" stopColor={getMoodColor(wellBeingLevel, percentage + 15)} />
                  </linearGradient>
                </defs>
              </svg>
              
              {/* Center Content */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <motion.div
                  animate={{ 
                    scale: isHovered ? 1.1 : 1,
                    rotate: isHovered ? 5 : 0
                  }}
                  className="text-6xl mb-2"
                >
                  {getMoodEmoji()}
                </motion.div>
                <motion.div
                  animate={{ scale: isHovered ? 1.05 : 1 }}
                  className="text-3xl font-bold text-gray-800"
                >
                  {percentage}%
                </motion.div>
                <Badge 
                  className={`mt-2 ${
                    wellBeingLevel === 'low' ? 'bg-blue-100 text-blue-800' :
                    wellBeingLevel === 'moderate' ? 'bg-green-100 text-green-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}
                >
                  {wellBeingLevel === 'low' ? 'Needs Support' :
                   wellBeingLevel === 'moderate' ? 'Doing Well' : 'Thriving'}
                </Badge>
              </div>
            </div>

            {/* Mood Message */}
            <motion.div
              animate={{ opacity: isHovered ? 1 : 0.8 }}
              className="text-center"
            >
              <p className="text-lg font-medium text-purple-800 mb-2">
                {getMoodMessage()}
              </p>
              <p className="text-sm text-gray-600">
                {isHovered ? 'Click to view detailed history' : 'Your weekly mood average'}
              </p>
            </motion.div>

            {/* Pulsing Effect for Significant Changes */}
            {percentage <= 30 && (
              <motion.div
                className="absolute inset-0 rounded-full border-4 border-red-300"
                animate={{
                  scale: [1, 1.1, 1],
                  opacity: [0.3, 0.6, 0.3]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}