import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { MoodEntry } from '@/lib/moodCalculations';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface ChartDataPoint {
  date: string;
  fullDate: string;
  mood: number;
  wellBeing: string;
  rawScore: number;
  day: number;
}

interface TooltipPayload {
  payload?: ChartDataPoint;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}

interface MoodTrendChartProps {
  moodEntries: MoodEntry[];
}

export default function MoodTrendChart({ moodEntries }: MoodTrendChartProps) {
  // Prepare data for the chart
  const chartData = moodEntries
    .slice(-14) // Last 14 days
    .map((entry, index) => ({
      date: entry.timestamp.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      fullDate: entry.timestamp.toLocaleDateString(),
      mood: entry.percentage,
      wellBeing: entry.wellBeingLevel,
      rawScore: entry.rawScore,
      day: index + 1
    }));

  // Calculate trend
  const calculateTrend = () => {
    if (chartData.length < 2) return 'stable';
    
    const recent = chartData.slice(-3);
    const earlier = chartData.slice(-6, -3);
    
    if (recent.length === 0 || earlier.length === 0) return 'stable';
    
    const recentAvg = recent.reduce((sum, entry) => sum + entry.mood, 0) / recent.length;
    const earlierAvg = earlier.reduce((sum, entry) => sum + entry.mood, 0) / earlier.length;
    
    const difference = recentAvg - earlierAvg;
    
    if (difference > 5) return 'improving';
    if (difference < -5) return 'declining';
    return 'stable';
  };

  const trend = calculateTrend();
  const averageMood = chartData.length > 0 
    ? Math.round(chartData.reduce((sum, entry) => sum + entry.mood, 0) / chartData.length)
    : 0;

  const getTrendIcon = () => {
    switch (trend) {
      case 'improving': return <TrendingUp className="w-5 h-5 text-green-600" />;
      case 'declining': return <TrendingDown className="w-5 h-5 text-red-600" />;
      default: return <Minus className="w-5 h-5 text-yellow-600" />;
    }
  };

  const getTrendMessage = () => {
    switch (trend) {
      case 'improving': return { text: "Your mood is trending upward! Keep it up, baddie! 📈", color: "text-green-700" };
      case 'declining': return { text: "Noticed a dip lately? That's okay - let's focus on some self-care 💜", color: "text-red-700" };
      default: return { text: "Your mood is staying steady - consistency is strength! ✨", color: "text-yellow-700" };
    }
  };

  const CustomTooltip = ({ active, payload, label }: CustomTooltipProps) => {
    if (active && payload && payload.length && payload[0].payload) {
      const data = payload[0].payload as ChartDataPoint;
      return (
        <div className="bg-white p-3 border-2 border-purple-200 rounded-lg shadow-lg">
          <p className="font-semibold text-purple-800">{data.fullDate}</p>
          <p className="text-purple-600">Mood Score: {data.mood}%</p>
          <p className="text-sm text-gray-600">Raw Score: {data.rawScore}/25</p>
          <p className="text-sm capitalize">
            Well-being: 
            <span className={`ml-1 font-medium ${
              data.wellBeing === 'low' ? 'text-red-600' :
              data.wellBeing === 'moderate' ? 'text-yellow-600' : 'text-green-600'
            }`}>
              {data.wellBeing}
            </span>
          </p>
        </div>
      );
    }
    return null;
  };

  if (chartData.length === 0) {
    return (
      <Card className="border-2 border-blue-200">
        <CardHeader>
          <CardTitle className="text-xl text-blue-800 flex items-center gap-2">
            📈 Mood Trends
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <div className="text-4xl mb-4">📊</div>
            <p className="text-lg mb-2">Start Your Journey!</p>
            <p className="text-sm">
              Complete a few more check-ins to see your mood trends and patterns.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="border-2 border-blue-200 shadow-lg">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl text-blue-800 flex items-center gap-2">
              📈 Mood Trends
            </CardTitle>
            <div className="flex items-center gap-2">
              {getTrendIcon()}
              <span className="text-sm font-medium text-gray-600">
                {trend}
              </span>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Trend Message */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border border-blue-200">
            <p className={`font-medium ${getTrendMessage().color}`}>
              {getTrendMessage().text}
            </p>
            <p className="text-sm text-gray-600 mt-1">
              14-day average: {averageMood}%
            </p>
          </div>

          {/* Chart */}
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="moodGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis 
                  dataKey="date" 
                  stroke="#6b7280"
                  fontSize={12}
                />
                <YAxis 
                  domain={[0, 100]}
                  stroke="#6b7280"
                  fontSize={12}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="mood"
                  stroke="#8b5cf6"
                  strokeWidth={3}
                  fill="url(#moodGradient)"
                  dot={{ fill: '#8b5cf6', strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, stroke: '#8b5cf6', strokeWidth: 2, fill: '#ffffff' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Mood Level Indicators */}
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="p-3 bg-red-50 rounded-lg border border-red-200">
              <div className="text-sm font-medium text-red-800">Low</div>
              <div className="text-xs text-red-600">0-50%</div>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <div className="text-sm font-medium text-yellow-800">Moderate</div>
              <div className="text-xs text-yellow-600">51-75%</div>
            </div>
            <div className="p-3 bg-green-50 rounded-lg border border-green-200">
              <div className="text-sm font-medium text-green-800">High</div>
              <div className="text-xs text-green-600">76-100%</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}