import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Play, ExternalLink, Clock, Heart, Zap, BookOpen } from 'lucide-react';

interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'article' | 'video' | 'exercise' | 'meditation' | 'podcast';
  duration: string;
  url: string;
  thumbnail?: string;
  creator?: string;
}

interface ResourceCarouselProps {
  wellBeingLevel: 'low' | 'moderate' | 'high' | null;
}

export default function ResourceCarousel({ wellBeingLevel }: ResourceCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const getResourcesForLevel = () => {
    const lowResources: Resource[] = [
      {
        id: '1',
        title: 'Breathing for Anxiety Relief',
        description: 'Quick 4-7-8 breathing technique to calm your nervous system',
        type: 'video',
        duration: '4 min',
        url: 'https://www.youtube.com/watch?v=YRPh_GaiL8s',
        thumbnail: 'https://img.youtube.com/vi/YRPh_GaiL8s/maxresdefault.jpg',
        creator: 'Dr. Andrew Weil'
      },
      {
        id: '2',
        title: 'Grounding Exercise',
        description: 'Use your 5 senses to feel present and safe',
        type: 'exercise',
        duration: '5 min',
        url: 'https://www.youtube.com/watch?v=30VMIEmA114',
        creator: 'Therapy in a Nutshell'
      },
      {
        id: '3',
        title: 'Crisis Support Resources',
        description: 'Immediate help when you need it most',
        type: 'article',
        duration: 'Immediate',
        url: 'https://www.crisistextline.org/',
        creator: 'Crisis Text Line'
      }
    ];

    const moderateResources: Resource[] = [
      {
        id: '4',
        title: 'Morning Meditation',
        description: 'Start your day with intention and calm',
        type: 'meditation',
        duration: '10 min',
        url: 'https://www.youtube.com/watch?v=inpok4MKVLM',
        thumbnail: 'https://img.youtube.com/vi/inpok4MKVLM/maxresdefault.jpg',
        creator: 'Headspace'
      },
      {
        id: '5',
        title: 'Self-Care Routines',
        description: 'Build sustainable wellness habits',
        type: 'video',
        duration: '12 min',
        url: 'https://www.youtube.com/watch?v=W9qsxhhNUoU',
        creator: 'Kati Morton'
      },
      {
        id: '6',
        title: 'Wellness Podcast',
        description: 'Inspiring stories of resilience and growth',
        type: 'podcast',
        duration: '25 min',
        url: 'https://open.spotify.com/show/5CvLsMVFStaLDkqISBYkY2',
        creator: 'The Happiness Lab'
      }
    ];

    const highResources: Resource[] = [
      {
        id: '7',
        title: 'Gratitude Practice',
        description: 'Science-backed happiness techniques',
        type: 'video',
        duration: '7 min',
        url: 'https://www.youtube.com/watch?v=WPPPFqsECz0',
        thumbnail: 'https://img.youtube.com/vi/WPPPFqsECz0/maxresdefault.jpg',
        creator: 'SoulPancake'
      },
      {
        id: '8',
        title: 'Goal Setting Workshop',
        description: 'Create meaningful goals that inspire you',
        type: 'video',
        duration: '14 min',
        url: 'https://www.youtube.com/watch?v=L4N1q4RNi9I',
        creator: 'Better Ideas'
      },
      {
        id: '9',
        title: 'Energy Boost Workout',
        description: 'Quick exercises to elevate your mood',
        type: 'exercise',
        duration: '15 min',
        url: 'https://www.youtube.com/watch?v=ml6cT4AZdqI',
        creator: 'HIIT Workouts'
      }
    ];

    switch (wellBeingLevel) {
      case 'low': return lowResources;
      case 'moderate': return moderateResources;
      case 'high': return highResources;
      default: return [...lowResources.slice(0, 1), ...moderateResources.slice(0, 1), ...highResources.slice(0, 1)];
    }
  };

  const resources = getResourcesForLevel();

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % resources.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + resources.length) % resources.length);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'video': return <Play className="w-4 h-4" />;
      case 'meditation': return <Heart className="w-4 h-4" />;
      case 'exercise': return <Zap className="w-4 h-4" />;
      case 'podcast': return <ExternalLink className="w-4 h-4" />;
      default: return <BookOpen className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'video': return 'bg-red-100 text-red-800';
      case 'meditation': return 'bg-purple-100 text-purple-800';
      case 'exercise': return 'bg-orange-100 text-orange-800';
      case 'podcast': return 'bg-green-100 text-green-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  if (resources.length === 0) return null;

  return (
    <Card className="border-2 border-pink-200 shadow-lg">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-pink-800">
            Recommended for You 💖
          </h3>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={prevSlide}
              disabled={resources.length <= 1}
              className="border-pink-300 text-pink-700 hover:bg-pink-50"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={nextSlide}
              disabled={resources.length <= 1}
              className="border-pink-300 text-pink-700 hover:bg-pink-50"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="relative overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 300 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -300 }}
              transition={{ duration: 0.3 }}
            >
              <Card 
                className="border border-pink-100 hover:shadow-lg transition-all duration-300 cursor-pointer"
                onClick={() => window.open(resources[currentIndex].url, '_blank')}
              >
                <CardContent className="p-0">
                  {resources[currentIndex].thumbnail && (
                    <div className="relative">
                      <img
                        src={resources[currentIndex].thumbnail}
                        alt={resources[currentIndex].title}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <Play className="w-12 h-12 text-white" />
                      </div>
                    </div>
                  )}
                  
                  <div className="p-4 space-y-3">
                    <div className="flex justify-between items-start">
                      <h4 className="font-semibold text-gray-800 flex-1">
                        {resources[currentIndex].title}
                      </h4>
                      <Badge className={`ml-2 ${getTypeColor(resources[currentIndex].type)}`}>
                        <div className="flex items-center gap-1">
                          {getTypeIcon(resources[currentIndex].type)}
                          {resources[currentIndex].type}
                        </div>
                      </Badge>
                    </div>
                    
                    {resources[currentIndex].creator && (
                      <p className="text-sm text-gray-500 font-medium">
                        by {resources[currentIndex].creator}
                      </p>
                    )}
                    
                    <p className="text-sm text-gray-600">
                      {resources[currentIndex].description}
                    </p>
                    
                    <div className="flex justify-between items-center pt-2">
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Clock className="w-4 h-4" />
                        {resources[currentIndex].duration}
                      </div>
                      
                      <Button
                        size="sm"
                        className="bg-pink-500 hover:bg-pink-600 text-white"
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open(resources[currentIndex].url, '_blank');
                        }}
                      >
                        {resources[currentIndex].type === 'video' ? 'Watch' : 'View'}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Dots Indicator */}
        {resources.length > 1 && (
          <div className="flex justify-center gap-2 mt-4">
            {resources.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentIndex ? 'bg-pink-500' : 'bg-pink-200'
                }`}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}