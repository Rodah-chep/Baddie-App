import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { WHO5_QUESTIONS, RATING_OPTIONS, WHO5Scores, calculateMoodScore, MoodEntry } from '@/lib/moodCalculations';
import { saveMoodEntry } from '@/lib/localStorage';
import { ChevronRight, Sparkles, Heart, CheckCircle } from 'lucide-react';

interface CheckInProps {
  onComplete: (entry: MoodEntry) => void;
}

export default function CheckIn({ onComplete }: CheckInProps) {
  const [scores, setScores] = useState<WHO5Scores>({
    cheerful: -1,
    calm: -1,
    active: -1,
    rested: -1,
    interest: -1
  });

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [showEncouragement, setShowEncouragement] = useState(false);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  const handleScoreChange = (value: number[]) => {
    const questionKey = WHO5_QUESTIONS[currentQuestion].key;
    setScores(prev => ({
      ...prev,
      [questionKey]: value[0]
    }));

    // Show encouragement animation
    setShowEncouragement(true);
    setTimeout(() => setShowEncouragement(false), 1500);

    // Auto-advance after a short delay
    setTimeout(() => {
      if (currentQuestion < WHO5_QUESTIONS.length - 1) {
        handleNext();
      }
    }, 1000);
  };

  const handleNext = () => {
    if (currentQuestion < WHO5_QUESTIONS.length - 1) {
      setIsAnimating(true);
      
      setTimeout(() => {
        setCurrentQuestion(prev => prev + 1);
        setIsAnimating(false);
        
        // Smooth scroll to next question
        setTimeout(() => {
          const nextCard = cardRefs.current[currentQuestion + 1];
          if (nextCard) {
            nextCard.scrollIntoView({ 
              behavior: 'smooth', 
              block: 'center',
              inline: 'nearest'
            });
          }
        }, 100);
      }, 300);
    } else {
      handleSubmit();
    }
  };

  const handleSubmit = () => {
    const { rawScore, percentage, wellBeingLevel } = calculateMoodScore(scores);
    
    const entry: MoodEntry = {
      id: `entry_${Date.now()}`,
      timestamp: new Date(),
      scores,
      rawScore,
      percentage,
      wellBeingLevel
    };

    saveMoodEntry(entry);
    onComplete(entry);
  };

  const getEncouragementMessage = (questionIndex: number) => {
    const messages = [
      "Great start, baddie! 💜",
      "You're doing amazing! ✨",
      "Keep going, you've got this! 🌟",
      "Almost there, superstar! 💫",
      "Last one - you're incredible! 🎉"
    ];
    return messages[questionIndex] || "Awesome! 💖";
  };

  const getQuestionEmoji = (questionIndex: number) => {
    const emojis = ["😊", "🧘‍♀️", "⚡", "😴", "🎯"];
    return emojis[questionIndex] || "💜";
  };

  const getCurrentSliderValue = () => {
    const questionKey = WHO5_QUESTIONS[currentQuestion].key;
    return scores[questionKey] === -1 ? [2] : [scores[questionKey]];
  };

  const isCurrentQuestionAnswered = () => {
    const questionKey = WHO5_QUESTIONS[currentQuestion].key;
    return scores[questionKey] !== -1;
  };

  const allQuestionsAnswered = () => {
    return Object.values(scores).every(score => score !== -1);
  };

  return (
    <div className="max-w-3xl mx-auto p-6 space-y-8">
      {/* Header with Progress */}
      <Card className="border-2 border-purple-200 shadow-lg bg-gradient-to-r from-purple-50 to-pink-50">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-purple-800 flex items-center justify-center gap-2">
            <Sparkles className="w-8 h-8 text-purple-600" />
            Daily Check-In
            <Sparkles className="w-8 h-8 text-purple-600" />
          </CardTitle>
          <CardDescription className="text-lg text-purple-700">
            Over the last two weeks, how often have you...
          </CardDescription>
          
          {/* Animated Progress Bar */}
          <div className="mt-6 space-y-3">
            <div className="flex justify-center items-center gap-2">
              {WHO5_QUESTIONS.map((_, index) => (
                <div
                  key={index}
                  className={`w-4 h-4 rounded-full transition-all duration-500 ${
                    index === currentQuestion
                      ? 'bg-purple-600 scale-125 shadow-lg'
                      : index < currentQuestion
                      ? 'bg-green-500 scale-110'
                      : 'bg-gray-200'
                  }`}
                />
              ))}
            </div>
            <div className="text-sm text-purple-600 font-medium">
              Question {currentQuestion + 1} of {WHO5_QUESTIONS.length}
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Questions */}
      {WHO5_QUESTIONS.map((question, index) => (
        <Card
          key={index}
          ref={el => cardRefs.current[index] = el}
          className={`border-2 shadow-lg transition-all duration-500 transform ${
            index === currentQuestion
              ? 'border-purple-300 scale-100 opacity-100 bg-white'
              : index < currentQuestion
              ? 'border-green-300 scale-95 opacity-75 bg-green-50'
              : 'border-gray-200 scale-90 opacity-50 bg-gray-50'
          } ${isAnimating && index === currentQuestion ? 'animate-pulse' : ''}`}
        >
          <CardHeader className="text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <span className="text-4xl">{getQuestionEmoji(index)}</span>
              <CardTitle className={`text-xl font-semibold transition-colors ${
                index === currentQuestion ? 'text-purple-800' : 
                index < currentQuestion ? 'text-green-700' : 'text-gray-500'
              }`}>
                {question.question}
              </CardTitle>
              {index < currentQuestion && (
                <CheckCircle className="w-6 h-6 text-green-600" />
              )}
            </div>
            <CardDescription className={`text-base ${
              index === currentQuestion ? 'text-purple-600' : 'text-gray-500'
            }`}>
              {question.description}
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            {index === currentQuestion && (
              <>
                {/* Interactive Slider */}
                <div className="space-y-6 px-4">
                  <div className="text-center">
                    <div className="text-6xl mb-4 transition-all duration-300">
                      {RATING_OPTIONS[getCurrentSliderValue()[0]]?.emoji || '😐'}
                    </div>
                    <div className="text-lg font-medium text-purple-800 mb-2">
                      {RATING_OPTIONS[getCurrentSliderValue()[0]]?.label || 'Select your feeling'}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Slider
                      value={getCurrentSliderValue()}
                      onValueChange={handleScoreChange}
                      max={5}
                      min={0}
                      step={1}
                      className="w-full"
                    />
                    
                    <div className="flex justify-between text-xs text-gray-500 px-2">
                      <span>At no time</span>
                      <span>Some time</span>
                      <span>Half time</span>
                      <span>Most time</span>
                      <span>All time</span>
                    </div>
                  </div>

                  {/* Emoji Scale */}
                  <div className="grid grid-cols-6 gap-2 mt-6">
                    {RATING_OPTIONS.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => handleScoreChange([option.value])}
                        className={`p-3 rounded-lg border-2 transition-all duration-200 hover:scale-110 ${
                          getCurrentSliderValue()[0] === option.value
                            ? 'border-purple-500 bg-purple-100 shadow-lg'
                            : 'border-gray-200 hover:border-purple-300'
                        }`}
                      >
                        <div className="text-2xl mb-1">{option.emoji}</div>
                        <div className="text-xs text-gray-600">{option.value}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Encouragement Message */}
                {showEncouragement && (
                  <div className="text-center animate-bounce">
                    <Badge className="bg-green-100 text-green-800 text-lg px-4 py-2">
                      <Heart className="w-4 h-4 mr-2" />
                      {getEncouragementMessage(currentQuestion)}
                    </Badge>
                  </div>
                )}
              </>
            )}

            {/* Navigation for current question */}
            {index === currentQuestion && (
              <div className="flex justify-center pt-6">
                {currentQuestion === WHO5_QUESTIONS.length - 1 && allQuestionsAnswered() ? (
                  <Button
                    onClick={handleSubmit}
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 text-lg"
                  >
                    <Sparkles className="w-5 h-5 mr-2" />
                    Complete Check-In
                  </Button>
                ) : isCurrentQuestionAnswered() ? (
                  <Button
                    onClick={handleNext}
                    className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 animate-pulse"
                  >
                    Next Question
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </Button>
                ) : null}
              </div>
            )}
          </CardContent>
        </Card>
      ))}

      {/* Completion Message */}
      {allQuestionsAnswered() && (
        <Card className="border-2 border-green-300 bg-gradient-to-r from-green-50 to-blue-50 shadow-lg">
          <CardContent className="text-center py-8">
            <div className="text-4xl mb-4">🎉</div>
            <h3 className="text-xl font-bold text-green-800 mb-2">
              Amazing work, baddie!
            </h3>
            <p className="text-green-700">
              You've completed your check-in. Ready to see your results and get personalized support? 💜
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}