import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Clock, Heart, Zap, Play, Video, BookOpen } from 'lucide-react';

interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'article' | 'video' | 'exercise' | 'meditation';
  duration: string;
  url: string;
  wellBeingLevel: 'low' | 'moderate' | 'high' | 'all';
  tags: string[];
  thumbnail?: string;
  videoId?: string;
  creator?: string;
}

const RESOURCES: Resource[] = [
  // Low Well-Being Resources
  {
    id: '1',
    title: '4-7-8 Breathing Technique for Instant Calm',
    description: 'Dr. Andrew Weil demonstrates this powerful breathing exercise that can help reduce anxiety in just a few minutes.',
    type: 'video',
    duration: '4 min',
    url: 'https://www.youtube.com/watch?v=YRPh_GaiL8s',
    videoId: 'YRPh_GaiL8s',
    wellBeingLevel: 'low',
    tags: ['anxiety', 'breathing', 'immediate relief'],
    creator: 'Dr. Andrew Weil',
    thumbnail: 'https://img.youtube.com/vi/YRPh_GaiL8s/maxresdefault.jpg'
  },
  {
    id: '2',
    title: 'Crisis Text Line - Free 24/7 Support',
    description: 'Text HOME to 741741 for free, confidential crisis counseling available 24/7.',
    type: 'article',
    duration: 'Immediate',
    url: 'https://www.crisistextline.org/',
    wellBeingLevel: 'low',
    tags: ['crisis support', 'immediate help', 'free']
  },
  {
    id: '3',
    title: '5-4-3-2-1 Grounding Technique',
    description: 'A therapist explains how to use your 5 senses to ground yourself during panic attacks or overwhelming emotions.',
    type: 'video',
    duration: '6 min',
    url: 'https://www.youtube.com/watch?v=30VMIEmA114',
    videoId: '30VMIEmA114',
    wellBeingLevel: 'low',
    tags: ['grounding', 'anxiety', 'mindfulness'],
    creator: 'Therapy in a Nutshell',
    thumbnail: 'https://img.youtube.com/vi/30VMIEmA114/maxresdefault.jpg'
  },
  {
    id: '4',
    title: 'Guided Body Scan for Anxiety Relief',
    description: 'A gentle 10-minute body scan meditation to help release tension and calm your nervous system.',
    type: 'meditation',
    duration: '10 min',
    url: 'https://www.youtube.com/watch?v=15q-N-_kkrU',
    videoId: '15q-N-_kkrU',
    wellBeingLevel: 'low',
    tags: ['meditation', 'body scan', 'relaxation'],
    creator: 'The Honest Guys',
    thumbnail: 'https://img.youtube.com/vi/15q-N-_kkrU/maxresdefault.jpg'
  },

  // Moderate Well-Being Resources
  {
    id: '5',
    title: 'Building Self-Care Routines That Actually Work',
    description: 'Practical tips for creating sustainable self-care habits that fit into your real life.',
    type: 'video',
    duration: '12 min',
    url: 'https://www.youtube.com/watch?v=W9qsxhhNUoU',
    videoId: 'W9qsxhhNUoU',
    wellBeingLevel: 'moderate',
    tags: ['self-care', 'routine', 'wellness'],
    creator: 'Kati Morton',
    thumbnail: 'https://img.youtube.com/vi/W9qsxhhNUoU/maxresdefault.jpg'
  },
  {
    id: '6',
    title: '10-Minute Morning Meditation',
    description: 'Start your day with intention and calm. Perfect for building a consistent mindfulness practice.',
    type: 'meditation',
    duration: '10 min',
    url: 'https://www.youtube.com/watch?v=inpok4MKVLM',
    videoId: 'inpok4MKVLM',
    wellBeingLevel: 'moderate',
    tags: ['meditation', 'morning routine', 'mindfulness'],
    creator: 'Headspace',
    thumbnail: 'https://img.youtube.com/vi/inpok4MKVLM/maxresdefault.jpg'
  },
  {
    id: '7',
    title: 'Journaling for Mental Health',
    description: 'Learn effective journaling techniques to process emotions and gain clarity about your thoughts.',
    type: 'video',
    duration: '8 min',
    url: 'https://www.youtube.com/watch?v=41H3s6rEtw8',
    videoId: '41H3s6rEtw8',
    wellBeingLevel: 'moderate',
    tags: ['journaling', 'self-reflection', 'emotional processing'],
    creator: 'Psych2Go',
    thumbnail: '/images/Journaling.jpg'
  },
  {
    id: '8',
    title: 'Gentle Yoga for Stress Relief',
    description: 'A soothing 15-minute yoga flow designed to release tension and promote relaxation.',
    type: 'exercise',
    duration: '15 min',
    url: 'https://www.youtube.com/watch?v=hJbRpHZr_d0',
    videoId: 'hJbRpHZr_d0',
    wellBeingLevel: 'moderate',
    tags: ['yoga', 'stress relief', 'movement'],
    creator: 'Yoga with Adriene',
    thumbnail: 'https://img.youtube.com/vi/hJbRpHZr_d0/maxresdefault.jpg'
  },

  // High Well-Being Resources
  {
    id: '9',
    title: 'The Science of Gratitude',
    description: 'Discover how gratitude practices can rewire your brain for happiness and resilience.',
    type: 'video',
    duration: '7 min',
    url: 'https://www.youtube.com/watch?v=WPPPFqsECz0',
    videoId: 'WPPPFqsECz0',
    wellBeingLevel: 'high',
    tags: ['gratitude', 'happiness', 'positive psychology'],
    creator: 'SoulPancake',
    thumbnail: 'https://img.youtube.com/vi/WPPPFqsECz0/maxresdefault.jpg'
  },
  {
    id: '10',
    title: 'Goal Setting for Personal Growth',
    description: 'Learn how to set meaningful goals that align with your values and create lasting change.',
    type: 'video',
    duration: '14 min',
    url: 'https://www.youtube.com/watch?v=L4N1q4RNi9I',
    videoId: 'L4N1q4RNi9I',
    wellBeingLevel: 'high',
    tags: ['goal setting', 'personal growth', 'achievement'],
    creator: 'Better Ideas',
    thumbnail: 'https://img.youtube.com/vi/L4N1q4RNi9I/maxresdefault.jpg'
  },
  {
    id: '11',
    title: 'Energizing Morning Workout',
    description: 'A fun, upbeat 20-minute workout to boost your energy and mood for the day ahead.',
    type: 'exercise',
    duration: '20 min',
    url: 'https://www.youtube.com/watch?v=ml6cT4AZdqI',
    videoId: 'ml6cT4AZdqI',
    wellBeingLevel: 'high',
    tags: ['exercise', 'energy', 'mood boost'],
    creator: 'HIIT Workouts',
    thumbnail: 'https://img.youtube.com/vi/ml6cT4AZdqI/maxresdefault.jpg'
  },
  {
    id: '12',
    title: 'Mindfulness in Daily Life',
    description: 'Simple techniques to stay present and mindful throughout your day, even when busy.',
    type: 'meditation',
    duration: '9 min',
    url: 'https://www.youtube.com/watch?v=F6eFFCi12v8',
    videoId: 'F6eFFCi12v8',
    wellBeingLevel: 'high',
    tags: ['mindfulness', 'daily practice', 'presence'],
    creator: 'Mindful',
    thumbnail: '/images/Mindfulness.jpg'
  }
];

interface ResourceLibraryProps {
  wellBeingLevel: 'low' | 'moderate' | 'high' | null;
}

export default function ResourceLibrary({ wellBeingLevel }: ResourceLibraryProps) {
  const getRelevantResources = () => {
    if (!wellBeingLevel) return RESOURCES.slice(0, 4);
    
    return RESOURCES.filter(resource => 
      resource.wellBeingLevel === wellBeingLevel || resource.wellBeingLevel === 'all'
    );
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'exercise': return <Zap className="w-4 h-4" />;
      case 'meditation': return <Heart className="w-4 h-4" />;
      case 'video': return <Video className="w-4 h-4" />;
      default: return <BookOpen className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'exercise': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'meditation': return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'video': return 'bg-blue-100 text-blue-800 border-blue-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getWellBeingMessage = () => {
    switch (wellBeingLevel) {
      case 'low':
        return {
          title: 'Support Resources for You 🫂',
          description: 'Here are some immediate support resources and gentle techniques to help you through this difficult time.',
          color: 'text-red-800'
        };
      case 'moderate':
        return {
          title: 'Wellness Boosters ✨',
          description: 'You\'re doing okay! Here are some resources to help you feel even better and build resilience.',
          color: 'text-yellow-800'
        };
      case 'high':
        return {
          title: 'Keep Thriving! 🌟',
          description: 'You\'re in a great place! Here are resources to help you maintain this positive energy and continue growing.',
          color: 'text-green-800'
        };
      default:
        return {
          title: 'Wellness Resources 💜',
          description: 'Explore these curated resources to support your mental health journey.',
          color: 'text-purple-800'
        };
    }
  };

  const relevantResources = getRelevantResources();
  const { title, description, color } = getWellBeingMessage();

  const handleResourceClick = (resource: Resource) => {
    // Track engagement (could be sent to analytics)
    console.log(`Resource clicked: ${resource.title}`);
    window.open(resource.url, '_blank');
  };

  return (
    <Card className="border-2 border-green-200">
      <CardHeader>
        <CardTitle className={`text-xl ${color}`}>{title}</CardTitle>
        <CardDescription className="text-green-700 text-base">
          {description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
          {relevantResources.map((resource) => (
            <Card 
              key={resource.id} 
              className="border border-green-100 hover:shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer group"
              onClick={() => handleResourceClick(resource)}
            >
              <CardContent className="p-0">
                {/* Video Thumbnail */}
                {resource.type === 'video' && resource.thumbnail && (
                  <div className="relative overflow-hidden rounded-t-lg">
                    <img
                      src={resource.thumbnail}
                      alt={resource.title}
                      className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="w-12 h-12 text-white" />
                    </div>
                    <Badge className="absolute top-3 left-3 bg-black bg-opacity-70 text-white">
                      <Clock className="w-3 h-3 mr-1" />
                      {resource.duration}
                    </Badge>
                  </div>
                )}

                <div className="p-4 space-y-3">
                  {/* Header */}
                  <div className="flex justify-between items-start">
                    <h4 className="font-semibold text-gray-800 flex-1 group-hover:text-green-700 transition-colors">
                      {resource.title}
                    </h4>
                    <Badge className={`ml-2 ${getTypeColor(resource.type)}`}>
                      <div className="flex items-center gap-1">
                        {getTypeIcon(resource.type)}
                        {resource.type}
                      </div>
                    </Badge>
                  </div>
                  
                  {/* Creator */}
                  {resource.creator && (
                    <p className="text-sm text-gray-500 font-medium">
                      by {resource.creator}
                    </p>
                  )}
                  
                  {/* Description */}
                  <p className="text-sm text-gray-600 line-clamp-2">
                    {resource.description}
                  </p>
                  
                  {/* Footer */}
                  <div className="flex justify-between items-center pt-2">
                    {resource.type !== 'video' && (
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Clock className="w-4 h-4" />
                        {resource.duration}
                      </div>
                    )}
                    
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-green-300 text-green-700 hover:bg-green-50 ml-auto"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleResourceClick(resource);
                      }}
                    >
                      {resource.type === 'video' ? (
                        <>
                          <Play className="w-4 h-4 mr-1" />
                          Watch
                        </>
                      ) : (
                        <>
                          <ExternalLink className="w-4 h-4 mr-1" />
                          View
                        </>
                      )}
                    </Button>
                  </div>
                  
                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 pt-2">
                    {resource.tags.slice(0, 3).map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="mt-8 text-center p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-green-200">
          <h3 className="text-lg font-semibold text-green-800 mb-2">
            Need More Support? 💚
          </h3>
          <p className="text-green-700 mb-4">
            These resources are just the beginning. Consider reaching out to a mental health professional for personalized support.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Button
              variant="outline"
              className="border-green-300 text-green-700 hover:bg-green-50"
              onClick={() => window.open('https://www.psychologytoday.com/us/therapists', '_blank')}
            >
              Find a Therapist
            </Button>
            <Button
              variant="outline"
              className="border-blue-300 text-blue-700 hover:bg-blue-50"
              onClick={() => window.open('https://www.betterhelp.com/', '_blank')}
            >
              Online Therapy
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}