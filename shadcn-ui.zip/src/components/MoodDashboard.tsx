import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MoodEntry } from '@/lib/moodCalculations';
import { getMoodTrend, getMoodEntries } from '@/lib/localStorage';
import CircularMoodMeter from './CircularMoodMeter';
import MoodTrendChart from './MoodTrendChart';
import BaddieBadges from './BaddieBadges';
import QuickActions from './QuickActions';
import ResourceCarousel from './ResourceCarousel';
import { motion } from 'framer-motion';

interface MoodDashboardProps {
  latestEntry: MoodEntry | null;
}

export default function MoodDashboard({ latestEntry }: MoodDashboardProps) {
  const [showDetailedHistory, setShowDetailedHistory] = useState(false);
  const recentTrend = getMoodTrend(7);
  const allEntries = getMoodEntries();

  // Calculate stats for badges
  const checkInStreak = calculateStreak();
  const totalCheckIns = allEntries.length;
  const resourcesViewed = parseInt(localStorage.getItem('baddie_resources_viewed') || '0');
  const moodImprovements = calculateMoodImprovements();

  function calculateStreak(): number {
    if (allEntries.length === 0) return 0;
    
    const today = new Date();
    let streak = 0;
    
    for (let i = 0; i < 30; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(today.getDate() - i);
      checkDate.setHours(0, 0, 0, 0);
      
      const hasEntry = allEntries.some(entry => {
        const entryDate = new Date(entry.timestamp);
        entryDate.setHours(0, 0, 0, 0);
        return entryDate.getTime() === checkDate.getTime();
      });
      
      if (hasEntry) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    
    return streak;
  }

  function calculateMoodImprovements(): number {
    let improvements = 0;
    for (let i = 1; i < allEntries.length; i++) {
      if (allEntries[i].percentage > allEntries[i - 1].percentage + 10) {
        improvements++;
      }
    }
    return improvements;
  }

  const handleActionClick = (action: string) => {
    // Track resource views
    const currentViews = parseInt(localStorage.getItem('baddie_resources_viewed') || '0');
    localStorage.setItem('baddie_resources_viewed', (currentViews + 1).toString());
  };

  if (!latestEntry) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-6"
      >
        <Card className="border-2 border-purple-200 shadow-lg bg-gradient-to-br from-purple-50 to-pink-50">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-purple-800 flex items-center justify-center gap-2">
              <span className="text-3xl">💜</span>
              Welcome, Baddie!
              <span className="text-3xl">💜</span>
            </CardTitle>
            <CardDescription className="text-lg text-purple-700">
              Ready to start your mental health journey? Let's check in with yourself!
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center py-8">
            <div className="space-y-4">
              <div className="text-6xl mb-4">✨</div>
              <p className="text-purple-600 font-medium">
                Your personalized dashboard will appear here after your first check-in
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Show badges even without entries */}
        <BaddieBadges 
          checkInStreak={0}
          totalCheckIns={0}
          resourcesViewed={resourcesViewed}
          moodImprovements={0}
        />

        {/* Default resource carousel */}
        <ResourceCarousel wellBeingLevel={null} />
      </motion.div>
    );
  }

  const averageWeeklyMood = recentTrend.length > 0 
    ? Math.round(recentTrend.reduce((sum, entry) => sum + entry.percentage, 0) / recentTrend.length)
    : latestEntry.percentage;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      {/* Main Mood Meter */}
      <CircularMoodMeter
        percentage={latestEntry.percentage}
        wellBeingLevel={latestEntry.wellBeingLevel}
        onExpand={() => setShowDetailedHistory(!showDetailedHistory)}
      />

      {/* Quick Actions */}
      <QuickActions 
        wellBeingLevel={latestEntry.wellBeingLevel}
        onActionClick={handleActionClick}
      />

      {/* Resource Carousel */}
      <ResourceCarousel wellBeingLevel={latestEntry.wellBeingLevel} />

      {/* Mood Trend Chart */}
      {(showDetailedHistory || recentTrend.length > 1) && (
        <MoodTrendChart moodEntries={allEntries} />
      )}

      {/* Badges System */}
      <BaddieBadges 
        checkInStreak={checkInStreak}
        totalCheckIns={totalCheckIns}
        resourcesViewed={resourcesViewed}
        moodImprovements={moodImprovements}
      />

      {/* Weekly Summary */}
      {recentTrend.length > 1 && (
        <Card className="border-2 border-indigo-200 bg-gradient-to-r from-indigo-50 to-purple-50">
          <CardHeader>
            <CardTitle className="text-lg text-indigo-800 flex items-center gap-2">
              📊 Weekly Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div className="p-3 bg-white rounded-lg border border-indigo-200">
                <div className="text-2xl font-bold text-indigo-600">{averageWeeklyMood}%</div>
                <div className="text-sm text-indigo-700">Weekly Average</div>
              </div>
              <div className="p-3 bg-white rounded-lg border border-indigo-200">
                <div className="text-2xl font-bold text-indigo-600">{checkInStreak}</div>
                <div className="text-sm text-indigo-700">Day Streak</div>
              </div>
              <div className="p-3 bg-white rounded-lg border border-indigo-200">
                <div className="text-2xl font-bold text-indigo-600">{totalCheckIns}</div>
                <div className="text-sm text-indigo-700">Total Check-ins</div>
              </div>
              <div className="p-3 bg-white rounded-lg border border-indigo-200">
                <div className="text-2xl font-bold text-indigo-600">{moodImprovements}</div>
                <div className="text-sm text-indigo-700">Improvements</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}