# Baddie Mental Health App - MVP Todo

## Core Features to Implement
1. **Daily Check-in Interface** - WHO-5 questionnaire with 5 questions (0-5 scale)
2. **Mood Scoring System** - Calculate raw score (0-25) and percentage (0-100%)
3. **Dashboard** - Display current mood, trends, and personalized recommendations
4. **Resource Library** - Curated mental health resources based on mood scores
5. **Anonymous User Experience** - Local storage for data persistence
6. **Risk Assessment** - Support mechanisms for low scores

## Files to Create/Modify
1. `src/pages/Index.tsx` - Main dashboard and navigation
2. `src/components/CheckIn.tsx` - WHO-5 questionnaire component
3. `src/components/MoodDashboard.tsx` - Mood tracking and visualization
4. `src/components/ResourceLibrary.tsx` - Personalized recommendations
5. `src/components/SupportAlert.tsx` - Risk assessment and support
6. `src/lib/moodCalculations.ts` - WHO-5 scoring logic
7. `src/lib/localStorage.ts` - Data persistence utilities
8. `index.html` - Update title and meta tags

## Mood Score Ranges
- 0-50%: Low Well-Being (intensive support)
- 51-75%: Moderate Well-Being (motivational resources)
- 76-100%: High Well-Being (maintenance resources)

## Implementation Priority
1. WHO-5 questionnaire and scoring
2. Basic dashboard with mood display
3. Resource recommendations
4. Data persistence
5. Risk assessment alerts